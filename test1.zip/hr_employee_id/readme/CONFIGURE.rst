If you want to modify the format of the sequence, go to
Settings -> Technical -> Sequences & Identifiers -> Sequences
and search for the "Employee ID" sequence, where you modify
its prefix and numbering formats.

To configure the 'ID Generation Method', the '# of Digits' and
the 'Sequence', activate the developer mode and go to
Employees -> Configuration -> Employee ID.
