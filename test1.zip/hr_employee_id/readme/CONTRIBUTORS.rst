* Michael Telahun Makonnen <mmakonnen@gmail.com>
* Adrien Peiffer (ACSONE) <adrien.peiffer@acsone.eu>
* Salton Massally (iDT Labs) <smassally@idtlabs.sl>
* Andhitia Rama (OpenSynergy Indonesia) <andhitia.r@gmail.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Alexey Pelykh <alexey.pelykh@brainbeanapps.com>
