Quick access of tasks of the employee
-------------------------------------

This module is a step forward to allow the user to have access to analysed information quickly.
This module helps any user to see the number of tasks on the employee from view and kanban view.
