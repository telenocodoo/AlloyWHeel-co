Project Task Timer
------------------------------------

Odoo Version : Odoo 11.0 Community

Installation 
-------------------------------------
Install the Application => Apps -> Project Task Timer

Project Task Timer Functionality
---------------------------------------------

Calculates project task duration automatically.