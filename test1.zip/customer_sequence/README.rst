Customer Sequence v12
=====================

This module will give a unique code to each customer and supplier.

Configuration
=============
You should configure the company form for the proper working of this module.
The supplier code will start from 0000,0001,.. and customer code start from the number you give in the company form

Further information
===================
I added a security file which gives access res.company for all users.
if you not configure the company form then the customer code start with 1,2,..and supplier code always start with 0001,0002,..

Installation
============
- www.odoo.com/documentation/11.0/setup/install.html
- Install our custom addon

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
Cybrosys Techno Solutions

Author
======
* Cybrosys Techno Solutions <https://www.cybrosys.com>
Developer : Vinaya (odoo@cybrosys.com) @ Cybrosys

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
