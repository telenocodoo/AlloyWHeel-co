* Simplify the function schedule_another_phonecall returning always a recordset
