* Odoo S.A.
* `Tecnativa <https://www.tecnativa.com>`_

  * Vicent Cubells <vicent.cubells@tecnativa.com>
  * Jairo Llopis <jairo.llopis@tecnativa.com>
  * David Vidal <david.vidal@tecnativa.com>

* Anand Kansagra <kansagraanand@hotmail.com>
